<template>
  <div id="app">
    <!-- <img alt="Vue logo" src="./assets/logo.png" /> -->
    <h2>A</h2>
    <div>
      <span>count: </span>
      <span>{{ getCountA }}</span>
    </div>
    <div>
      <span>test: </span>
      <span>{{ getTestA }}</span>
    </div>
    <div>
      <!-- <button @click="console.log('click')">add</button> -->
      <button @click="addA">add</button>
    </div>
    <div>
      <input type="text" v-model="textA" />
      <button @click="dispatchChangeA">change</button>
    </div>
    <div>
      {{ getList }}
    </div>
    <!--  -->
    <h2>B</h2>
    <div>
      <span>count: </span>
      <span>{{ getCountB }}</span>
    </div>
    <div>
      <span>test: </span>
      <span>{{ getTestB }}</span>
    </div>
    <div>
      <!-- <button @click="console.log('click')">add</button> -->
      <button @click="addB">add</button>
    </div>
    <div>
      <input type="text" v-model="textB" />
      <button>change</button>
    </div>
  </div>
</template>

<script>
import { rootComputed, rootMethods } from "@/store/helpers";
export default {
  name: "App",
  components: {},
  data() {
    return {
      textA: '',
      textB: ''
    }
  },
  computed: {
    ...rootComputed,
  },
  methods: {
    ...rootMethods,
    dispatchChangeA: function () {
      this.textA = ''
    },
    dispatchCHangeB: function () {

    }
  }
};
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
