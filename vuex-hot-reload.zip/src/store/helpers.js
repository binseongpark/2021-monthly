import { mapState, mapGetters, mapActions, mapMutations } from 'vuex'

export const rootComputed = {
  console: () => console,
  ...mapGetters('a', [
    'getTestA',
    'getCountA',
    'getList'
  ]),
  ...mapGetters('b', [
    'getTestB',
    'getCountB',

  ])
}
export const rootMethods = {
  ...mapActions('a', [
    'addA',
    'defaultAssignA'
  ]),
  ...mapActions('b', [
    'addB',
    'defaultAssignB'
  ])
}
