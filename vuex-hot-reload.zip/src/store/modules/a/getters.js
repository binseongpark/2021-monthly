export default {
  getTestA: (state) => {
    console.log('state: ', state)
    return state.test
  },
  getCountA: (state) => {
    return state.count
  },
  getList: (state) => {
    return state.list
      .slice(-3)
      .join(',')
  }
}
