import * as types from './mutation-types'

export default {
  addA({ commit }) {
    commit(types.ADD)
  },
  defaultAssignA({ commit }, { s }) {
    commit(types.DEFAULT_ASSIGN, s)
  }
}
