import actions from './actions'
import getters from './getters'
import mutations from './mutations'

const state = () => ({
  test: 'a',
  count: 0,
  list: [
    '123',
    '123',
    '123',
    '123',
    '123',
    '123',
    '123',
    '123',
    '123',
    '123',
  ]
})

export default {
  namespaced: true,
  state,
  actions,
  getters,
  mutations
}
