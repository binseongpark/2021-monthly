import * as types from './mutation-types'

export default {
  addB({ commit }) {
    commit(types.ADD)
  },
  defaultAssignB({ commit }, { s }) {
    commit(types.DEFAULT_ASSIGN, s)
  }
}
