export default {
  getTestB: (state) => {
    console.log('state: ', state)
    return state.test
  },
  getCountB: (state) => {
    return state.count
  }
}
