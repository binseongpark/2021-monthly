import * as types from './mutation-types'

export default {
  [types.ADD]: (state) => {
    console.log('@@@@ state: ', state)
    state.count++
  },
  [types.DEFAULT_ASSIGN]: (state, payload) => {
    console.log('@@@@ state: ', state)
    console.log('@@@@ payload: ', payload)
  }
}
