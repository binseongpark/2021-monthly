import Vue from 'vue'
import Vuex from 'vuex'

import a from './modules/a'
import b from './modules/b'

Vue.use(Vuex)

const store = new Vuex.Store({
  modules: {
    a,
    b
  },
  strict: process.env.NODE_ENV === 'development'
})

if (module.hot) {
  module.hot.accept(['./modules/a', './modules/b'], () => {
    const newModuleA = require('./modules/a').default
    const newModuleB = require('./modules/b').default
    store.hotUpdate({
      modules: {
        a: newModuleA,
        b: newModuleB
      }
    })
  })
}

export default store
